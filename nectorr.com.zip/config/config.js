module.exports = {

	twitter: {
        'consumer_key': 'wj888T3jlauiQIjcdu751AELB'
        , 'consumer_secret': 'oFTPhjo0TN7myprULXrk4Wl1WtY2H9lYu9wrIrQkicXtljwwii'
        , 'access_token': '103259010-9AtPODqSaurMAOaIiIfnJrr14TloFKXgx9wElaop'
        , 'access_token_secret': 'pJWeIvX69HhXr3f6WicjEbZfhWLDezcjUzcXbVBWsyEF5'
        , 'redirect_url': 'http://127.0.0.1:1337/auth/twitter/callback'
        // for updating to git once again and again
        //,
        //bearer_token:''
        //test
	},
    facebookAuth: {
        'client_id': '334582780223007'
        , 'client_secret': '85f5abe5d8390c9134c9dd84befa26ed'
        , 'redirect_uri': 'http://localhost:1337/auth/facebook/callback'
        , 'code': 'EAAEwTRZCDXh8BAL5AtzF9Lt5VAu2aKYnGHLIz7h0MmkpSogLyQ4nK7lH4HNiGV13PJRVWKd3vZAu4MxZAZCmkqkxIasQZAcZByhwvvd5eqyYDlMS7M04uagHAXa9mNwTrZCtPxYhRDotE6MlinTmhtQBCnTsE8JHcJUyZB0ZChkTidAZDZD'
        //,
        //bearer_token:''
        //test
    }

};