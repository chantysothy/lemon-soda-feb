// config/database.js
module.exports = {

	'url' : 'mongodb://127.0.0.1:27017/nectrr' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

};