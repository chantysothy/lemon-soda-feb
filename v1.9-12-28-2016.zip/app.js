var express = require('express');
var path = require('path');
var router = require('./routes/index');
var tweets = require('./routes/tweets');
var google = require('./routes/google');
var mongodb = require('mongodb');
var mongoose = require('mongoose');
var passport = require('passport');

var configDB = require('./config/database.js');

// configuration ===============================================================
mongoose.connect(configDB.url); // connect to our database
require('./config/passport')(passport); // pass passport for configuration

var app = express();

//app.route(router);
// serve static assets from the public directory
//app.configure(function);
app.use(function (req, res, next) {
    res.header('X-XSS-Protection', 0);
    res.header('X-App-Name', 'nectorr');
    res.header('Access-Control-Allow-Origin', '*');
    return next();
});
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions

app.use(express.static(path.join(__dirname, 'public')));
//app.use(express.cookieParser()); // read cookies (needed for auth)
//app.use(express.bodyParser()); // get information from html forms


// look for view html in the views directory
app.set('views', path.join(__dirname, 'views'));

// use ejs to render 
app.set('view engine', 'ejs');

// setup routes
app.use('/', router);
app.use(google);
//app.use('/tweets', tweets);


module.exports = app;

var port = 1337;//process.env.PORT || 5000;
app.listen(port, function() {
  console.log('nectorr.com is listening on ' + port);
});
