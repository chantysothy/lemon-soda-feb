module.exports = {

	twitter: {
  	'consumer_key': 'wj888T3jlauiQIjcdu751AELB'
		,  'consumer_secret': 'oFTPhjo0TN7myprULXrk4Wl1WtY2H9lYu9wrIrQkicXtljwwii'
		, 'access_token': '103259010-14Fslxo1BpoGsEMCVKz41qxrj9aIRSRvzED9Q1an'
        , 'access_token_secret': 'l6YKbEkcAvFkCAiEBpbBT52GOfBuMcB6yAxyqPYxjzLBz'
        , 'redirect_url':'http://localhost:1337/auth/twitter/callback'
        //,
        //bearer_token:''
	},
    facebookAuth: {
        'client_id': '334582780223007'
        , 'client_secret': '85f5abe5d8390c9134c9dd84befa26ed'
        , 'redirect_uri': 'http://localhost:1337/auth/facebook/callback'
        , 'code': 'EAAEwTRZCDXh8BAL5AtzF9Lt5VAu2aKYnGHLIz7h0MmkpSogLyQ4nK7lH4HNiGV13PJRVWKd3vZAu4MxZAZCmkqkxIasQZAcZByhwvvd5eqyYDlMS7M04uagHAXa9mNwTrZCtPxYhRDotE6MlinTmhtQBCnTsE8JHcJUyZB0ZChkTidAZDZD'
        //,
        //bearer_token:''
    }

};